print("Hello, Lua speaking again.");

p1,p2 = HelloWorld(10, 20, 30);
print "Results:";
print (p1, p2);

HelloWorld2();
HelloWorld3();



